package com.example.data.model

data class UserProfile(
    val authPhone: String = "",
    val name: String = "",
    val contactNumber: String = "",
    val deliveryAddress: String = ""
) {
    val isComplete: Boolean
        get() = name.isNotBlank() && contactNumber.isNotBlank() && deliveryAddress.isNotBlank()
}

data class DesignAttachment(
    val uriString: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long
) {
    val isPdf: Boolean
        get() = mimeType.contains("pdf", ignoreCase = true) ||
            fileName.endsWith(".pdf", ignoreCase = true)

    val formattedSize: String
        get() = when {
            sizeBytes <= 0L -> "File attached"
            sizeBytes < 1024L -> "$sizeBytes B"
            sizeBytes < 1024L * 1024L -> "${sizeBytes / 1024L} KB"
            else -> String.format("%.1f MB", sizeBytes / (1024f * 1024f))
        }
}

sealed interface DesignOption {
    data object None : DesignOption
    data class UploadedFile(val attachment: DesignAttachment) : DesignOption
    data object MakeNewDesignRequested : DesignOption
}

sealed interface PaymentStatus {
    data object Idle : PaymentStatus
    data object AwaitingExternalConfirmation : PaymentStatus
    data class Confirmed(val referenceId: String) : PaymentStatus
}
