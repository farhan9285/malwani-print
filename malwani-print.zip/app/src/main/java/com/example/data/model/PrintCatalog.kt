package com.example.data.model

import androidx.annotation.DrawableRes
import com.example.R
import java.text.NumberFormat
import java.util.Locale

enum class PrintProductId {
    VISITING_CARD,
    PAMPHLET,
    LETTERHEAD,
    ENVELOPE
}

enum class PrintSideOption(val label: String) {
    FRONT_ONLY("Front Only"),
    FRONT_BACK("Front/Back")
}

data class FlatPrintOption(
    val id: String,
    val label: String,
    val specDetail: String,
    val priceInr: Int
)

data class PamphletSizeOption(
    val id: String,
    val label: String,
    val specDetail: String,
    val frontOnlyPriceInr: Int,
    val frontBackPriceInr: Int
) {
    fun priceFor(side: PrintSideOption): Int = when (side) {
        PrintSideOption.FRONT_ONLY -> frontOnlyPriceInr
        PrintSideOption.FRONT_BACK -> frontBackPriceInr
    }
}

sealed interface PrintProductCatalogItem {
    val id: PrintProductId
    val title: String
    val subtitle: String
    val categoryTag: String
    @get:DrawableRes val imageRes: Int

    data class FlatOptionsProduct(
        override val id: PrintProductId,
        override val title: String,
        override val subtitle: String,
        override val categoryTag: String,
        @get:DrawableRes override val imageRes: Int,
        val options: List<FlatPrintOption>
    ) : PrintProductCatalogItem

    data class PamphletProduct(
        override val id: PrintProductId = PrintProductId.PAMPHLET,
        override val title: String = "Pamphlet",
        override val subtitle: String = "Crisp full-color promotional flyers & handouts",
        override val categoryTag: String = "MARKETING",
        @get:DrawableRes override val imageRes: Int = R.drawable.img_pamphlet,
        val sizeOptions: List<PamphletSizeOption>
    ) : PrintProductCatalogItem
}

data class SelectedPrintOrder(
    val productId: PrintProductId,
    val productName: String,
    val configurationLabel: String,
    val priceInr: Int
) {
    val displayTitle: String
        get() = "$productName - $configurationLabel"

    val formattedPrice: String
        get() = formatInr(priceInr)
}

object PrintCatalog {
    val visitingCard = PrintProductCatalogItem.FlatOptionsProduct(
        id = PrintProductId.VISITING_CARD,
        title = "Visiting Card",
        subtitle = "Standard 1,000 card pack • Sharp offset finish",
        categoryTag = "IDENTITY",
        imageRes = R.drawable.img_visiting_card,
        options = listOf(
            FlatPrintOption(
                id = "vc_250_gsm",
                label = "250 GSM",
                specDetail = "Matte card stock",
                priceInr = 500
            ),
            FlatPrintOption(
                id = "vc_nt",
                label = "NT Non-Tearable",
                specDetail = "Waterproof synthetic",
                priceInr = 700
            ),
            FlatPrintOption(
                id = "vc_350_gsm",
                label = "350 GSM",
                specDetail = "Heavy luxury board",
                priceInr = 1000
            )
        )
    )

    val pamphlet = PrintProductCatalogItem.PamphletProduct(
        sizeOptions = listOf(
            PamphletSizeOption(
                id = "pamphlet_a5_1000",
                label = "A5 Size 1000 Qty",
                specDetail = "148 x 210 mm • 1,000 sheets",
                frontOnlyPriceInr = 1000,
                frontBackPriceInr = 1400
            ),
            PamphletSizeOption(
                id = "pamphlet_a5_2000",
                label = "A5 Size 2000 Qty",
                specDetail = "148 x 210 mm • 2,000 sheets",
                frontOnlyPriceInr = 1800,
                frontBackPriceInr = 2200
            ),
            PamphletSizeOption(
                id = "pamphlet_a4_1000",
                label = "A4 Size 1000 Qty",
                specDetail = "210 x 297 mm • 1,000 sheets",
                frontOnlyPriceInr = 1850,
                frontBackPriceInr = 2050
            )
        )
    )

    val letterhead = PrintProductCatalogItem.FlatOptionsProduct(
        id = PrintProductId.LETTERHEAD,
        title = "Letterhead",
        subtitle = "Executive A4 office stationery • Bond finish",
        categoryTag = "STATIONERY",
        imageRes = R.drawable.img_letterhead,
        options = listOf(
            FlatPrintOption(
                id = "lh_90_gsm",
                label = "90 GSM",
                specDetail = "Sunshine bond paper",
                priceInr = 1500
            )
        )
    )

    val envelope = PrintProductCatalogItem.FlatOptionsProduct(
        id = PrintProductId.ENVELOPE,
        title = "Envelope",
        subtitle = "Custom-branded business mailers",
        categoryTag = "MAILERS",
        imageRes = R.drawable.img_envelope,
        options = listOf(
            FlatPrintOption(
                id = "env_9x4",
                label = "9x4 Size",
                specDetail = "DL office mailer",
                priceInr = 1800
            ),
            FlatPrintOption(
                id = "env_6x8",
                label = "6x8 Size",
                specDetail = "A5 document mailer",
                priceInr = 2550
            )
        )
    )

    val allProducts: List<PrintProductCatalogItem> = listOf(
        visitingCard,
        pamphlet,
        letterhead,
        envelope
    )
}

fun formatInr(amount: Int): String {
    val formatter = NumberFormat.getIntegerInstance(Locale("en", "IN"))
    return "₹${formatter.format(amount)}"
}
