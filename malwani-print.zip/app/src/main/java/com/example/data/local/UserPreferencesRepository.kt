package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.UserProfile
import java.security.MessageDigest
import java.security.SecureRandom
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.malwaniDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "malwani_print_prefs"
)

data class StoredSessionState(
    val isInitialized: Boolean = false,
    val isLoggedIn: Boolean = false,
    val profile: UserProfile = UserProfile()
)

sealed interface AuthResult {
    data object Success : AuthResult
    data class Error(val message: String) : AuthResult
}

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val LOGGED_IN_PHONE = stringPreferencesKey("logged_in_phone")
        fun pinHashKey(phone: String) = stringPreferencesKey("pin_hash_$phone")
        fun pinSaltKey(phone: String) = stringPreferencesKey("pin_salt_$phone")
        fun nameKey(phone: String) = stringPreferencesKey("profile_name_$phone")
        fun contactKey(phone: String) = stringPreferencesKey("profile_contact_$phone")
        fun addressKey(phone: String) = stringPreferencesKey("profile_address_$phone")
    }

    val sessionFlow: Flow<StoredSessionState> = context.malwaniDataStore.data.map { prefs ->
        val phone = prefs[Keys.LOGGED_IN_PHONE].orEmpty()
        if (phone.isBlank()) {
            StoredSessionState(isInitialized = true, isLoggedIn = false, profile = UserProfile())
        } else {
            val profile = UserProfile(
                authPhone = phone,
                name = prefs[Keys.nameKey(phone)].orEmpty(),
                contactNumber = prefs[Keys.contactKey(phone)].orEmpty().ifBlank { "+91 $phone" },
                deliveryAddress = prefs[Keys.addressKey(phone)].orEmpty()
            )
            StoredSessionState(
                isInitialized = true,
                isLoggedIn = true,
                profile = profile
            )
        }
    }

    suspend fun hasRegisteredAccount(rawPhone: String): Boolean {
        val phone = normalizePhone(rawPhone)
        if (phone.length != 10) return false
        val prefs = context.malwaniDataStore.data.first()
        return !prefs[Keys.pinHashKey(phone)].isNullOrBlank()
    }

    suspend fun signUpWithPhoneAndPin(rawPhone: String, pin: String): AuthResult {
        val phone = normalizePhone(rawPhone)
        if (!isValidIndianMobile(phone)) {
            return AuthResult.Error("Enter a valid 10-digit Indian mobile number.")
        }
        if (pin.length != 4 || !pin.all { it.isDigit() }) {
            return AuthResult.Error("Create a 4-digit numeric security PIN.")
        }
        val prefs = context.malwaniDataStore.data.first()
        if (!prefs[Keys.pinHashKey(phone)].isNullOrBlank()) {
            return AuthResult.Error("Account already exists for +91 $phone. Please sign in.")
        }
        val salt = generateSaltHex()
        val hash = sha256Hex("$salt:$phone:$pin")
        context.malwaniDataStore.edit { editable ->
            editable[Keys.pinSaltKey(phone)] = salt
            editable[Keys.pinHashKey(phone)] = hash
            editable[Keys.LOGGED_IN_PHONE] = phone
            if (editable[Keys.contactKey(phone)].isNullOrBlank()) {
                editable[Keys.contactKey(phone)] = "+91 $phone"
            }
        }
        return AuthResult.Success
    }

    suspend fun signInWithPhoneAndPin(rawPhone: String, pin: String): AuthResult {
        val phone = normalizePhone(rawPhone)
        if (!isValidIndianMobile(phone)) {
            return AuthResult.Error("Enter a valid 10-digit Indian mobile number.")
        }
        if (pin.length != 4 || !pin.all { it.isDigit() }) {
            return AuthResult.Error("Enter your 4-digit security PIN.")
        }
        val prefs = context.malwaniDataStore.data.first()
        val storedSalt = prefs[Keys.pinSaltKey(phone)]
        val storedHash = prefs[Keys.pinHashKey(phone)]
        if (storedSalt.isNullOrBlank() || storedHash.isNullOrBlank()) {
            return AuthResult.Error("No account found for +91 $phone. Switch to Create Account.")
        }
        val computedHash = sha256Hex("$storedSalt:$phone:$pin")
        if (computedHash != storedHash) {
            return AuthResult.Error("Incorrect PIN for +91 $phone. Please try again.")
        }
        context.malwaniDataStore.edit { editable ->
            editable[Keys.LOGGED_IN_PHONE] = phone
        }
        return AuthResult.Success
    }

    suspend fun saveProfile(
        name: String,
        contactNumber: String,
        deliveryAddress: String
    ) {
        val prefs = context.malwaniDataStore.data.first()
        val phone = prefs[Keys.LOGGED_IN_PHONE].orEmpty()
        if (phone.isBlank()) return
        context.malwaniDataStore.edit { editable ->
            editable[Keys.nameKey(phone)] = name.trim()
            editable[Keys.contactKey(phone)] = contactNumber.trim()
            editable[Keys.addressKey(phone)] = deliveryAddress.trim()
        }
    }

    suspend fun signOut() {
        context.malwaniDataStore.edit { editable ->
            editable.remove(Keys.LOGGED_IN_PHONE)
        }
    }

    companion object {
        fun normalizePhone(input: String): String {
            val digits = input.filter { it.isDigit() }
            return if (digits.length > 10 && digits.startsWith("91")) {
                digits.takeLast(10)
            } else {
                digits.take(10)
            }
        }

        fun isValidIndianMobile(digits: String): Boolean {
            return digits.length == 10 && digits.first() in setOf('6', '7', '8', '9')
        }

        private fun generateSaltHex(): String {
            val bytes = ByteArray(16)
            SecureRandom().nextBytes(bytes)
            return bytes.joinToString("") { "%02x".format(it) }
        }

        private fun sha256Hex(input: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(input.toByteArray(Charsets.UTF_8))
            return digest.joinToString("") { "%02x".format(it) }
        }
    }
}
