package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.UserPreferencesRepository
import com.example.ui.MainViewModel
import com.example.ui.navigation.MalwaniAppRoot
import com.example.ui.theme.MalwaniPrintTheme

class MainActivity : ComponentActivity() {

    private val repository by lazy { UserPreferencesRepository(applicationContext) }
    private val viewModel: MainViewModel by viewModels {
        MainViewModel.Factory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        setContent {
            MalwaniPrintTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                MalwaniAppRoot(
                    uiState = uiState,
                    viewModel = viewModel
                )
            }
        }
    }
}
