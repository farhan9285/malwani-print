package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.DesignAttachment
import com.example.data.model.SelectedPrintOrder
import com.example.data.model.UserProfile
import java.net.URLEncoder

object MalwaniPrintConstants {
    const val BUSINESS_NAME = "Malwani Print"
    const val UPI_ID = "farhanupi@hdfcbank"
    const val UPI_PAYEE_NAME = "Malwani Print"
    const val WHATSAPP_DISPLAY_NUMBER = "+918850209468"
    const val WHATSAPP_DIGITS = "918850209468"

    const val GPAY_PACKAGE = "com.google.android.apps.nbu.paisa.user"
    const val PHONEPE_PACKAGE = "com.phonepe.app"
    const val PAYTM_PACKAGE = "net.one97.paytm"
    const val WHATSAPP_PACKAGE = "com.whatsapp"
    const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b"
}

data class InstalledUpiApps(
    val hasGPay: Boolean,
    val hasPhonePe: Boolean,
    val hasPaytm: Boolean,
    val hasAnyUpiHandler: Boolean
)

data class UpiParsedResult(
    val isSuccess: Boolean,
    val transactionRef: String,
    val statusText: String
)

object ExternalIntents {

    fun buildOrderSummaryMessage(
        profile: UserProfile,
        order: SelectedPrintOrder
    ): String {
        return buildString {
            appendLine("New Order on Malwani Print!")
            appendLine("Customer: ${profile.name}")
            appendLine("Phone: ${profile.contactNumber}")
            appendLine("Address: ${profile.deliveryAddress}")
            appendLine("Product: ${order.displayTitle}")
            append("Amount Paid: ${order.formattedPrice} (Paid via UPI)")
        }
    }

    fun buildDesignHelpMessage(
        profile: UserProfile,
        order: SelectedPrintOrder
    ): String {
        return buildString {
            appendLine("Hi Malwani Print! I need help designing a new artwork.")
            appendLine("Customer: ${profile.name}")
            appendLine("Phone: ${profile.contactNumber}")
            append("Product: ${order.displayTitle} (${order.formattedPrice})")
        }
    }

    fun queryInstalledUpiApps(context: Context): InstalledUpiApps {
        val pm = context.packageManager
        val genericUpiIntent = Intent(Intent.ACTION_VIEW, Uri.parse("upi://pay"))
        val handlers = pm.queryIntentActivities(genericUpiIntent, PackageManager.MATCH_DEFAULT_ONLY)
        return InstalledUpiApps(
            hasGPay = isPackageInstalled(pm, MalwaniPrintConstants.GPAY_PACKAGE),
            hasPhonePe = isPackageInstalled(pm, MalwaniPrintConstants.PHONEPE_PACKAGE),
            hasPaytm = isPackageInstalled(pm, MalwaniPrintConstants.PAYTM_PACKAGE),
            hasAnyUpiHandler = handlers.isNotEmpty()
        )
    }

    fun createUpiPayIntent(
        amountInr: Int,
        transactionNote: String,
        targetPackage: String? = null
    ): Intent {
        val txnRef = "MP${System.currentTimeMillis()}"
        val uri = Uri.Builder()
            .scheme("upi")
            .authority("pay")
            .appendQueryParameter("pa", MalwaniPrintConstants.UPI_ID)
            .appendQueryParameter("pn", MalwaniPrintConstants.UPI_PAYEE_NAME)
            .appendQueryParameter("tr", txnRef)
            .appendQueryParameter("tn", transactionNote)
            .appendQueryParameter("am", "$amountInr.00")
            .appendQueryParameter("cu", "INR")
            .build()

        return Intent(Intent.ACTION_VIEW, uri).apply {
            if (!targetPackage.isNullOrBlank()) {
                setPackage(targetPackage)
            }
        }
    }

    fun parseUpiResponse(data: Intent?): UpiParsedResult {
        val response = data?.getStringExtra("response").orEmpty()
        val statusExtra = data?.getStringExtra("Status").orEmpty()
        val combined = "$response&$statusExtra"
        val params = combined.split("&")
            .mapNotNull { part ->
                val idx = part.indexOf('=')
                if (idx > 0) {
                    part.substring(0, idx).lowercase() to part.substring(idx + 1)
                } else {
                    null
                }
            }
            .toMap()

        val status = params["status"].orEmpty()
        val ref = params["approvalrefno"]
            ?: params["txnref"]
            ?: params["txnid"]
            ?: "UPI-${System.currentTimeMillis().toString().takeLast(6)}"

        val isSuccess = status.equals("success", ignoreCase = true) ||
            status.equals("submitted", ignoreCase = true)

        return UpiParsedResult(
            isSuccess = isSuccess,
            transactionRef = ref,
            statusText = status
        )
    }

    fun openWhatsAppWithMessage(context: Context, message: String): Boolean {
        val encodedText = URLEncoder.encode(message, "UTF-8")
        val waUri = Uri.parse(
            "https://api.whatsapp.com/send?phone=${MalwaniPrintConstants.WHATSAPP_DIGITS}&text=$encodedText"
        )
        val pm = context.packageManager

        val preferredPackage = when {
            isPackageInstalled(pm, MalwaniPrintConstants.WHATSAPP_PACKAGE) ->
                MalwaniPrintConstants.WHATSAPP_PACKAGE
            isPackageInstalled(pm, MalwaniPrintConstants.WHATSAPP_BUSINESS_PACKAGE) ->
                MalwaniPrintConstants.WHATSAPP_BUSINESS_PACKAGE
            else -> null
        }

        val intent = Intent(Intent.ACTION_VIEW, waUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (preferredPackage != null) {
                setPackage(preferredPackage)
            }
        }

        return runCatching {
            context.startActivity(intent)
            true
        }.getOrElse {
            // Fallback without explicit package if browser / universal link handles it
            val fallback = Intent(Intent.ACTION_VIEW, waUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching {
                context.startActivity(fallback)
                true
            }.getOrDefault(false)
        }
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    fun readAttachmentMetadata(context: Context, uri: Uri): DesignAttachment {
        val resolver = context.contentResolver
        val mimeType = resolver.getType(uri) ?: "application/octet-stream"
        var fileName = "artwork_file"
        var sizeBytes = 0L

        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) {
                    fileName = cursor.getString(nameIndex) ?: fileName
                }
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                    sizeBytes = cursor.getLong(sizeIndex)
                }
            }
        }

        return DesignAttachment(
            uriString = uri.toString(),
            fileName = fileName,
            mimeType = mimeType,
            sizeBytes = sizeBytes
        )
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return runCatching {
            pm.getPackageInfo(packageName, 0)
            true
        }.getOrDefault(false)
    }
}
