package com.example.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.MainViewModel
import com.example.ui.MalwaniUiState
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileSetupScreen

object MalwaniRoutes {
    const val ROUTE_AUTH = "auth"
    const val ROUTE_PROFILE_SETUP = "profile_setup"
    const val ROUTE_HOME = "home"
    const val ROUTE_CHECKOUT = "checkout"
    const val ROUTE_PROFILE_EDIT = "profile_edit"
}

@Composable
fun MalwaniAppRoot(
    uiState: MalwaniUiState,
    viewModel: MainViewModel
) {
    val session = uiState.session
    if (!session.isInitialized) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
        return
    }

    if (!session.isLoggedIn) {
        AuthScreen(
            authState = uiState.auth,
            onModeChanged = viewModel::setAuthMode,
            onPhoneChanged = viewModel::onPhoneInputChanged,
            onPinChanged = viewModel::onPinInputChanged,
            onOtpChanged = viewModel::onOtpInputChanged,
            onSubmit = viewModel::requestOtpOrSubmitAuth
        )
        return
    }

    if (!session.profile.isComplete) {
        ProfileSetupScreen(
            existingProfile = session.profile,
            isEditing = false,
            onBack = null,
            onSaveProfile = { name, contact, address ->
                viewModel.saveUserProfile(name, contact, address) {}
            }
        )
        return
    }

    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = MalwaniRoutes.ROUTE_HOME
    ) {
        composable(MalwaniRoutes.ROUTE_HOME) {
            HomeScreen(
                profile = session.profile,
                catalogSelection = uiState.catalog,
                selectedOrder = uiState.selectedOrder,
                onSelectVisitingCard = viewModel::selectVisitingCard,
                onSelectPamphletSize = viewModel::selectPamphletSize,
                onSelectPamphletSide = viewModel::selectPamphletSide,
                onSelectLetterhead = viewModel::selectLetterhead,
                onSelectEnvelope = viewModel::selectEnvelope,
                onActivateProduct = viewModel::activateProduct,
                onEditProfile = {
                    navController.navigate(MalwaniRoutes.ROUTE_PROFILE_EDIT)
                },
                onSignOut = viewModel::signOut,
                onProceedToCheckout = {
                    navController.navigate(MalwaniRoutes.ROUTE_CHECKOUT)
                }
            )
        }

        composable(MalwaniRoutes.ROUTE_CHECKOUT) {
            CheckoutScreen(
                profile = session.profile,
                selectedOrder = uiState.selectedOrder,
                checkoutState = uiState.checkout,
                onBack = { navController.popBackStack() },
                onEditProfile = {
                    navController.navigate(MalwaniRoutes.ROUTE_PROFILE_EDIT)
                },
                onDesignUploaded = viewModel::onDesignUploaded,
                onMakeNewDesignSelected = viewModel::onMakeNewDesignSelected,
                onClearDesign = viewModel::clearDesignAttachment,
                onWarnDesignRequired = viewModel::warnDesignRequired,
                onUpiInitiated = viewModel::markUpiInitiated,
                onPaymentConfirmed = { ref ->
                    viewModel.confirmUpiPayment(ref, session.profile)
                },
                onPlaceAnotherOrder = {
                    viewModel.resetOrderForNewPurchase()
                    navController.popBackStack(MalwaniRoutes.ROUTE_HOME, inclusive = false)
                }
            )
        }

        composable(MalwaniRoutes.ROUTE_PROFILE_EDIT) {
            ProfileSetupScreen(
                existingProfile = session.profile,
                isEditing = true,
                onBack = { navController.popBackStack() },
                onSaveProfile = { name, contact, address ->
                    viewModel.saveUserProfile(name, contact, address) {
                        navController.popBackStack()
                    }
                }
            )
        }
    }
}
