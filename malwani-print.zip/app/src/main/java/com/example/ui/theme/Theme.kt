package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val MalwaniLightColorScheme = lightColorScheme(
    primary = SoftTeal,
    onPrimary = Color.White,
    primaryContainer = PastelCyanContainer,
    onPrimaryContainer = OnPastelCyanContainer,
    secondary = PastelRose,
    onSecondary = Color.White,
    secondaryContainer = PastelRoseContainer,
    onSecondaryContainer = OnPastelRoseContainer,
    tertiary = PastelOchre,
    onTertiary = Color.White,
    tertiaryContainer = PastelOchreContainer,
    onTertiaryContainer = OnPastelOchreContainer,
    background = WarmOffWhite,
    onBackground = MutedCharcoal,
    surface = WarmPaper,
    onSurface = MutedCharcoal,
    surfaceVariant = WarmSurfaceLow,
    onSurfaceVariant = CharcoalMuted,
    surfaceContainerLowest = WarmPaper,
    surfaceContainerLow = WarmSurfaceLow,
    surfaceContainer = WarmSurfaceContainer,
    surfaceContainerHigh = WarmSurfaceHigh,
    outline = WarmOutline,
    outlineVariant = WarmOutlineVariant,
    error = PastelError,
    onError = Color.White,
    errorContainer = PastelErrorContainer,
    onErrorContainer = OnPastelErrorContainer
)

val MalwaniShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MalwaniPrintTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MalwaniLightColorScheme,
        typography = MalwaniTypography,
        shapes = MalwaniShapes,
        content = content
    )
}
