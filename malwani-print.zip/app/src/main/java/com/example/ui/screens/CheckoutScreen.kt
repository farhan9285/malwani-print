package com.example.ui.screens

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DesignServices
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.DesignAttachment
import com.example.data.model.DesignOption
import com.example.data.model.PaymentStatus
import com.example.data.model.SelectedPrintOrder
import com.example.data.model.UserProfile
import com.example.ui.CheckoutUiState
import com.example.ui.theme.SuccessSage
import com.example.ui.theme.SuccessSageContainer
import com.example.ui.theme.OnSuccessSageContainer
import com.example.util.ExternalIntents
import com.example.util.MalwaniPrintConstants

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    profile: UserProfile,
    selectedOrder: SelectedPrintOrder,
    checkoutState: CheckoutUiState,
    onBack: () -> Unit,
    onEditProfile: () -> Unit,
    onDesignUploaded: (DesignAttachment) -> Unit,
    onMakeNewDesignSelected: () -> Unit,
    onClearDesign: () -> Unit,
    onWarnDesignRequired: () -> Unit,
    onUpiInitiated: () -> Unit,
    onPaymentConfirmed: (referenceId: String) -> String,
    onPlaceAnotherOrder: () -> Unit
) {
    val context = LocalContext.current
    var showUpiSheet by remember { mutableStateOf(false) }
    var showManualConfirmDialog by remember { mutableStateOf(false) }
    var utrInput by remember { mutableStateOf("") }

    val installedUpiApps = remember(showUpiSheet) {
        ExternalIntents.queryInstalledUpiApps(context)
    }

    // Zero-permission SAF Document Picker for local PDF or Image artwork
    val designPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val attachment = ExternalIntents.readAttachmentMetadata(context, uri)
            onDesignUploaded(attachment)
        }
    }

    // UPI Payment Activity Result Launcher
    val upiLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val parsed = ExternalIntents.parseUpiResponse(result.data)
        if (result.resultCode == Activity.RESULT_OK && parsed.isSuccess) {
            val summary = onPaymentConfirmed(parsed.transactionRef)
            ExternalIntents.openWhatsAppWithMessage(context, summary)
        } else {
            // Some UPI apps return without standard extras or user cancelled; allow verification dialog
            showManualConfirmDialog = true
        }
    }

    val launchUpiIntent: (String?) -> Unit = { targetPackage ->
        onUpiInitiated()
        showUpiSheet = false
        val intent = ExternalIntents.createUpiPayIntent(
            amountInr = selectedOrder.priceInr,
            transactionNote = "Malwani Print: ${selectedOrder.displayTitle}",
            targetPackage = targetPackage
        )
        val launched = runCatching {
            upiLauncher.launch(intent)
            true
        }.getOrDefault(false)

        if (!launched) {
            Toast.makeText(
                context,
                "No matching UPI app found on this device. You can pay via ${MalwaniPrintConstants.UPI_ID} and confirm below.",
                Toast.LENGTH_LONG
            ).show()
            showManualConfirmDialog = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (checkoutState.paymentStatus is PaymentStatus.Confirmed) {
                            "Order Confirmed"
                        } else {
                            "Order & Checkout"
                        }
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("checkout_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to catalog"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (checkoutState.paymentStatus is PaymentStatus.Confirmed) {
                    OrderConfirmedReceiptCard(
                        summary = checkoutState.lastOrderSummary
                            ?: ExternalIntents.buildOrderSummaryMessage(profile, selectedOrder),
                        referenceId = checkoutState.paymentStatus.referenceId,
                        uploadedFileName = (checkoutState.designOption as? DesignOption.UploadedFile)?.attachment?.fileName,
                        onOpenWhatsAppAgain = {
                            val message = checkoutState.lastOrderSummary
                                ?: ExternalIntents.buildOrderSummaryMessage(profile, selectedOrder)
                            val opened = ExternalIntents.openWhatsAppWithMessage(context, message)
                            if (!opened) {
                                Toast.makeText(
                                    context,
                                    "Could not launch WhatsApp. Order text copied to clipboard.",
                                    Toast.LENGTH_LONG
                                ).show()
                                ExternalIntents.copyToClipboard(context, "Malwani Print Order", message)
                            }
                        },
                        onPlaceAnotherOrder = onPlaceAnotherOrder
                    )
                } else {
                    // 1. Order & Bill Summary
                    OrderSummaryCard(
                        selectedOrder = selectedOrder,
                        profile = profile,
                        onEditProfile = onEditProfile
                    )

                    // 2. Mandatory Design Options: Upload Design + Make New Design
                    DesignWorkflowCard(
                        designOption = checkoutState.designOption,
                        showWarning = checkoutState.showDesignRequirementWarning,
                        onUploadDesignClick = {
                            designPickerLauncher.launch(arrayOf("application/pdf", "image/*"))
                        },
                        onMakeNewDesignClick = {
                            onMakeNewDesignSelected()
                            val helpMsg = ExternalIntents.buildDesignHelpMessage(profile, selectedOrder)
                            val opened = ExternalIntents.openWhatsAppWithMessage(context, helpMsg)
                            if (!opened) {
                                ExternalIntents.copyToClipboard(context, "Design Help Request", helpMsg)
                                Toast.makeText(
                                    context,
                                    "WhatsApp not found. Message copied — send to ${MalwaniPrintConstants.WHATSAPP_DISPLAY_NUMBER}.",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        onClearDesign = onClearDesign
                    )

                    // 3. 100% Full Advance UPI Payment Card
                    UpiPaymentCard(
                        selectedOrder = selectedOrder,
                        awaitingConfirmation = checkoutState.paymentStatus is PaymentStatus.AwaitingExternalConfirmation,
                        onPayViaUpiClick = {
                            if (checkoutState.designOption is DesignOption.None) {
                                onWarnDesignRequired()
                            } else {
                                showUpiSheet = true
                            }
                        },
                        onConfirmPaidManually = { showManualConfirmDialog = true },
                        onCopyUpiId = {
                            ExternalIntents.copyToClipboard(
                                context,
                                "Malwani Print UPI ID",
                                MalwaniPrintConstants.UPI_ID
                            )
                            Toast.makeText(
                                context,
                                "Copied ${MalwaniPrintConstants.UPI_ID}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    )
                }
            }
        }
    }

    if (showUpiSheet) {
        ModalBottomSheet(
            onDismissRequest = { showUpiSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Pay ${selectedOrder.formattedPrice} via UPI",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "100% advance payment to ${MalwaniPrintConstants.UPI_ID}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                UpiAppChoiceRow(
                    title = "Google Pay",
                    subtitle = if (installedUpiApps.hasGPay) "Installed • Fast UPI checkout" else "Launch Google Pay",
                    badgeText = if (installedUpiApps.hasGPay) "READY" else "INTENT",
                    onClick = { launchUpiIntent(MalwaniPrintConstants.GPAY_PACKAGE) },
                    modifier = Modifier.testTag("upi_option_gpay")
                )

                UpiAppChoiceRow(
                    title = "PhonePe",
                    subtitle = if (installedUpiApps.hasPhonePe) "Installed • Fast UPI checkout" else "Launch PhonePe",
                    badgeText = if (installedUpiApps.hasPhonePe) "READY" else "INTENT",
                    onClick = { launchUpiIntent(MalwaniPrintConstants.PHONEPE_PACKAGE) },
                    modifier = Modifier.testTag("upi_option_phonepe")
                )

                UpiAppChoiceRow(
                    title = "Any Installed UPI App",
                    subtitle = if (installedUpiApps.hasAnyUpiHandler) "Open Android UPI chooser" else "Pay via UPI app & confirm",
                    badgeText = "UPI",
                    onClick = { launchUpiIntent(null) },
                    modifier = Modifier.testTag("upi_option_generic")
                )

                Spacer(modifier = Modifier.height(6.dp))
            }
        }
    }

    if (showManualConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showManualConfirmDialog = false },
            title = { Text("Confirm UPI Payment") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Completed your ${selectedOrder.formattedPrice} advance payment to ${MalwaniPrintConstants.UPI_ID}? Enter your 12-digit UPI Ref/UTR (optional) to send your order directly to Malwani Print on WhatsApp.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = utrInput,
                        onValueChange = { utrInput = it },
                        label = { Text("UPI Reference / UTR (Optional)") },
                        placeholder = { Text("e.g., 432198765432") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("upi_utr_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showManualConfirmDialog = false
                        val summary = onPaymentConfirmed(utrInput)
                        ExternalIntents.openWhatsAppWithMessage(context, summary)
                    },
                    modifier = Modifier.testTag("confirm_upi_payment_button")
                ) {
                    Text("Confirm & Open WhatsApp")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun OrderSummaryCard(
    selectedOrder: SelectedPrintOrder,
    profile: UserProfile,
    onEditProfile: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "SELECTED PRINT ITEM",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = selectedOrder.productName,
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = selectedOrder.configurationLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = selectedOrder.formattedPrice,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "DELIVERY TO",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${profile.name} • ${profile.contactNumber}",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = profile.deliveryAddress,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(
                    onClick = onEditProfile,
                    modifier = Modifier.testTag("checkout_edit_profile_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Edit,
                        contentDescription = "Edit delivery details",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit")
                }
            }
        }
    }
}

@Composable
private fun DesignWorkflowCard(
    designOption: DesignOption,
    showWarning: Boolean,
    onUploadDesignClick: () -> Unit,
    onMakeNewDesignClick: () -> Unit,
    onClearDesign: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (showWarning) {
            BorderStroke(1.5.dp, MaterialTheme.colorScheme.error)
        } else {
            null
        },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Artwork & Design",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Choose how you'd like to provide your print design before UPI payment:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Two Mandatory Design Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onUploadDesignClick,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (designOption is DesignOption.UploadedFile) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.primaryContainer
                        },
                        contentColor = if (designOption is DesignOption.UploadedFile) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        }
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 54.dp)
                        .testTag("upload_design_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.UploadFile,
                        contentDescription = "Upload design file",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Upload Design",
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = onMakeNewDesignClick,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        width = if (designOption is DesignOption.MakeNewDesignRequested) 2.dp else 1.dp,
                        color = MaterialTheme.colorScheme.secondary
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (designOption is DesignOption.MakeNewDesignRequested) {
                            MaterialTheme.colorScheme.secondaryContainer
                        } else {
                            MaterialTheme.colorScheme.surface
                        },
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 54.dp)
                        .testTag("make_new_design_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DesignServices,
                        contentDescription = "Request new design on WhatsApp",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Make New Design",
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            AnimatedVisibility(visible = showWarning) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Please either Upload Design (PDF/Image) or tap Make New Design before paying via UPI.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            when (designOption) {
                is DesignOption.UploadedFile -> {
                    val file = designOption.attachment
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (file.isPdf) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.secondaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PictureAsPdf,
                                        contentDescription = "PDF artwork",
                                        tint = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            } else {
                                AsyncImage(
                                    model = Uri.parse(file.uriString),
                                    contentDescription = "Uploaded design preview",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = file.fileName,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${if (file.isPdf) "PDF Document" else "Image Artwork"} • ${file.formattedSize}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = onClearDesign,
                                modifier = Modifier.testTag("clear_design_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "Remove selected artwork"
                                )
                            }
                        }
                    }
                }

                DesignOption.MakeNewDesignRequested -> {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Design help requested",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Design assistance selected — WhatsApp opened with your product brief. Proceed to 100% UPI advance payment below.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }

                DesignOption.None -> Unit
            }
        }
    }
}

@Composable
private fun UpiPaymentCard(
    selectedOrder: SelectedPrintOrder,
    awaitingConfirmation: Boolean,
    onPayViaUpiClick: () -> Unit,
    onConfirmPaidManually: () -> Unit,
    onCopyUpiId: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "100% Full Advance Payment",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Orders enter production upon full UPI payment.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "100% ADVANCE",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "MERCHANT UPI ID",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = MalwaniPrintConstants.UPI_ID,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = onCopyUpiId,
                        modifier = Modifier.testTag("copy_upi_id_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ContentCopy,
                            contentDescription = "Copy UPI ID",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Button(
                onClick = onPayViaUpiClick,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 54.dp)
                    .testTag("pay_via_upi_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.AccountBalanceWallet,
                    contentDescription = "Pay via UPI",
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Pay ${selectedOrder.formattedPrice} via UPI",
                    style = MaterialTheme.typography.labelLarge
                )
            }

            if (awaitingConfirmation) {
                OutlinedButton(
                    onClick = onConfirmPaidManually,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("verify_upi_completed_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Verified,
                        contentDescription = "Verify completed UPI payment",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("I've Paid via UPI — Send Order to WhatsApp")
                }
            }
        }
    }
}

@Composable
private fun UpiAppChoiceRow(
    title: String,
    subtitle: String,
    badgeText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 60.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun OrderConfirmedReceiptCard(
    summary: String,
    referenceId: String,
    uploadedFileName: String?,
    onOpenWhatsAppAgain: () -> Unit,
    onPlaceAnotherOrder: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(SuccessSageContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "Payment confirmed",
                        tint = SuccessSage,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Payment Confirmed!",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Ref: $referenceId",
                        style = MaterialTheme.typography.labelSmall,
                        color = OnSuccessSageContainer
                    )
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(14.dp)
                )
            }

            if (!uploadedFileName.isNullOrBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Tip: Please attach your file ($uploadedFileName) directly inside the Malwani Print WhatsApp chat.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Button(
                onClick = onOpenWhatsAppAgain,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .testTag("send_whatsapp_order_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send order on WhatsApp",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Send Order on WhatsApp (${MalwaniPrintConstants.WHATSAPP_DISPLAY_NUMBER})")
            }

            OutlinedButton(
                onClick = onPlaceAnotherOrder,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("place_another_order_button")
            ) {
                Text("Back to Print Catalog")
            }
        }
    }
}
