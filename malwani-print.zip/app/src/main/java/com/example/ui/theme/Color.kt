package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// English Pastel CMYK Palette — Soft Teal primary, warm off-white paper background, muted charcoal ink
val WarmOffWhite = Color(0xFFFAF7F2)
val WarmPaper = Color(0xFFFFFFFF)
val WarmSurfaceLow = Color(0xFFF4EFE6)
val WarmSurfaceContainer = Color(0xFFEDE6DA)
val WarmSurfaceHigh = Color(0xFFE5DDD0)

val SoftTeal = Color(0xFF3E7F82)         // Pastel Cyan-Teal (Primary)
val SoftTealDark = Color(0xFF28595B)
val PastelCyanContainer = Color(0xFFCDE7E7)
val OnPastelCyanContainer = Color(0xFF133A3C)

val PastelRose = Color(0xFFB56E80)       // Pastel Magenta-Rose (Secondary)
val PastelRoseContainer = Color(0xFFF3DCE2)
val OnPastelRoseContainer = Color(0xFF471F2A)

val PastelOchre = Color(0xFFC49A4E)      // Pastel Yellow-Ochre (Tertiary)
val PastelOchreContainer = Color(0xFFF6EAD0)
val OnPastelOchreContainer = Color(0xFF43310D)

val MutedCharcoal = Color(0xFF2B2E33)    // Ink Black (K)
val CharcoalMuted = Color(0xFF5D636A)
val WarmOutline = Color(0xFFD5CCB9)
val WarmOutlineVariant = Color(0xFFE6DFD2)

val PastelError = Color(0xFFBA4D4D)
val PastelErrorContainer = Color(0xFFF9E1E1)
val OnPastelErrorContainer = Color(0xFF4E1414)

val SuccessSage = Color(0xFF3C7A5D)
val SuccessSageContainer = Color(0xFFD6EDE1)
val OnSuccessSageContainer = Color(0xFF143827)

// CMYK Micro Registration Dot Accents
val CmykCyanDot = Color(0xFF5BA4A8)
val CmykMagentaDot = Color(0xFFD2879B)
val CmykYellowDot = Color(0xFFE0B96B)
val CmykBlackDot = Color(0xFF3A3E44)
