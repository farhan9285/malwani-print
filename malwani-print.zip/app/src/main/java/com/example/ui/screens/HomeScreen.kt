package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.PamphletSizeOption
import com.example.data.model.PrintCatalog
import com.example.data.model.PrintProductCatalogItem
import com.example.data.model.PrintProductId
import com.example.data.model.PrintSideOption
import com.example.data.model.SelectedPrintOrder
import com.example.data.model.UserProfile
import com.example.data.model.formatInr
import com.example.ui.CatalogSelectionState
import com.example.ui.components.BusinessLogoPlaceholder
import com.example.ui.components.CmykRegistrationDots

@Composable
fun HomeScreen(
    profile: UserProfile,
    catalogSelection: CatalogSelectionState,
    selectedOrder: SelectedPrintOrder,
    onSelectVisitingCard: (String) -> Unit,
    onSelectPamphletSize: (String) -> Unit,
    onSelectPamphletSide: (PrintSideOption) -> Unit,
    onSelectLetterhead: (String) -> Unit,
    onSelectEnvelope: (String) -> Unit,
    onActivateProduct: (PrintProductId) -> Unit,
    onEditProfile: () -> Unit,
    onSignOut: () -> Unit,
    onProceedToCheckout: () -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            InstantBillBottomBar(
                selectedOrder = selectedOrder,
                onProceedToCheckout = onProceedToCheckout
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isWideScreen = maxWidth >= 660.dp

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 14.dp,
                    bottom = 24.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Column(
                        modifier = Modifier.widthIn(max = 980.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Top clean Business Logo Placeholder
                        BusinessLogoPlaceholder(
                            modifier = Modifier.testTag("business_logo_placeholder")
                        )

                        // Customer bar with saved name & profile actions
                        SavedCustomerBar(
                            profile = profile,
                            onEditProfile = onEditProfile,
                            onSignOut = onSignOut
                        )

                        // Catalog Heading
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Print Catalog & Pricing",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = "Select a product and specification to calculate your bill instantly",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            CmykRegistrationDots(dotSize = 6.dp, spacing = 4.dp)
                        }
                    }
                }

                if (isWideScreen) {
                    item {
                        Column(
                            modifier = Modifier.widthIn(max = 980.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(modifier = Modifier.weight(1f)) {
                                    FlatProductCard(
                                        product = PrintCatalog.visitingCard,
                                        isActiveProduct = catalogSelection.activeProductId == PrintProductId.VISITING_CARD,
                                        selectedOptionId = catalogSelection.visitingCardOptionId,
                                        onCardClick = { onActivateProduct(PrintProductId.VISITING_CARD) },
                                        onSelectOption = onSelectVisitingCard
                                    )
                                }
                                Box(modifier = Modifier.weight(1f)) {
                                    PamphletProductCard(
                                        product = PrintCatalog.pamphlet,
                                        isActiveProduct = catalogSelection.activeProductId == PrintProductId.PAMPHLET,
                                        selectedSizeId = catalogSelection.pamphletSizeId,
                                        selectedSide = catalogSelection.pamphletSide,
                                        onCardClick = { onActivateProduct(PrintProductId.PAMPHLET) },
                                        onSelectSize = onSelectPamphletSize,
                                        onSelectSide = onSelectPamphletSide
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(modifier = Modifier.weight(1f)) {
                                    FlatProductCard(
                                        product = PrintCatalog.letterhead,
                                        isActiveProduct = catalogSelection.activeProductId == PrintProductId.LETTERHEAD,
                                        selectedOptionId = catalogSelection.letterheadOptionId,
                                        onCardClick = { onActivateProduct(PrintProductId.LETTERHEAD) },
                                        onSelectOption = onSelectLetterhead
                                    )
                                }
                                Box(modifier = Modifier.weight(1f)) {
                                    FlatProductCard(
                                        product = PrintCatalog.envelope,
                                        isActiveProduct = catalogSelection.activeProductId == PrintProductId.ENVELOPE,
                                        selectedOptionId = catalogSelection.envelopeOptionId,
                                        onCardClick = { onActivateProduct(PrintProductId.ENVELOPE) },
                                        onSelectOption = onSelectEnvelope
                                    )
                                }
                            }
                        }
                    }
                } else {
                    item {
                        FlatProductCard(
                            product = PrintCatalog.visitingCard,
                            isActiveProduct = catalogSelection.activeProductId == PrintProductId.VISITING_CARD,
                            selectedOptionId = catalogSelection.visitingCardOptionId,
                            onCardClick = { onActivateProduct(PrintProductId.VISITING_CARD) },
                            onSelectOption = onSelectVisitingCard,
                            modifier = Modifier.widthIn(max = 600.dp)
                        )
                    }
                    item {
                        PamphletProductCard(
                            product = PrintCatalog.pamphlet,
                            isActiveProduct = catalogSelection.activeProductId == PrintProductId.PAMPHLET,
                            selectedSizeId = catalogSelection.pamphletSizeId,
                            selectedSide = catalogSelection.pamphletSide,
                            onCardClick = { onActivateProduct(PrintProductId.PAMPHLET) },
                            onSelectSize = onSelectPamphletSize,
                            onSelectSide = onSelectPamphletSide,
                            modifier = Modifier.widthIn(max = 600.dp)
                        )
                    }
                    item {
                        FlatProductCard(
                            product = PrintCatalog.letterhead,
                            isActiveProduct = catalogSelection.activeProductId == PrintProductId.LETTERHEAD,
                            selectedOptionId = catalogSelection.letterheadOptionId,
                            onCardClick = { onActivateProduct(PrintProductId.LETTERHEAD) },
                            onSelectOption = onSelectLetterhead,
                            modifier = Modifier.widthIn(max = 600.dp)
                        )
                    }
                    item {
                        FlatProductCard(
                            product = PrintCatalog.envelope,
                            isActiveProduct = catalogSelection.activeProductId == PrintProductId.ENVELOPE,
                            selectedOptionId = catalogSelection.envelopeOptionId,
                            onCardClick = { onActivateProduct(PrintProductId.ENVELOPE) },
                            onSelectOption = onSelectEnvelope,
                            modifier = Modifier.widthIn(max = 600.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SavedCustomerBar(
    profile: UserProfile,
    onEditProfile: () -> Unit,
    onSignOut: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Person,
                    contentDescription = "Customer profile icon",
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = profile.name.ifBlank { "Customer" },
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${profile.contactNumber} • ${profile.deliveryAddress}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(
                onClick = onEditProfile,
                modifier = Modifier.testTag("home_edit_profile_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Edit,
                    contentDescription = "Edit saved profile",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(
                onClick = onSignOut,
                modifier = Modifier.testTag("home_sign_out_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.Logout,
                    contentDescription = "Sign out",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun FlatProductCard(
    product: PrintProductCatalogItem.FlatOptionsProduct,
    isActiveProduct: Boolean,
    selectedOptionId: String,
    onCardClick: () -> Unit,
    onSelectOption: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor by animateColorAsState(
        targetValue = if (isActiveProduct) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.outlineVariant
        },
        label = "product_card_border"
    )

    Card(
        onClick = onCardClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id.name.lowercase()}"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = if (isActiveProduct) 2.dp else 1.dp,
            color = borderColor
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isActiveProduct) 4.dp else 1.dp
        )
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            ProductCardHeader(
                title = product.title,
                subtitle = product.subtitle,
                categoryTag = product.categoryTag,
                imageRes = product.imageRes,
                isActive = isActiveProduct
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Select Specification",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                product.options.forEach { option ->
                    val isOptionSelected = isActiveProduct && selectedOptionId == option.id
                    OptionPriceRow(
                        label = option.label,
                        detail = option.specDetail,
                        priceInr = option.priceInr,
                        selected = isOptionSelected,
                        onClick = { onSelectOption(option.id) },
                        modifier = Modifier.testTag("option_${option.id}")
                    )
                }
            }
        }
    }
}

@Composable
private fun PamphletProductCard(
    product: PrintProductCatalogItem.PamphletProduct,
    isActiveProduct: Boolean,
    selectedSizeId: String,
    selectedSide: PrintSideOption,
    onCardClick: () -> Unit,
    onSelectSize: (String) -> Unit,
    onSelectSide: (PrintSideOption) -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor by animateColorAsState(
        targetValue = if (isActiveProduct) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.outlineVariant
        },
        label = "pamphlet_card_border"
    )
    val activeSizeOption: PamphletSizeOption = product.sizeOptions
        .firstOrNull { it.id == selectedSizeId }
        ?: product.sizeOptions.first()

    Card(
        onClick = onCardClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("product_card_pamphlet"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = if (isActiveProduct) 2.dp else 1.dp,
            color = borderColor
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isActiveProduct) 4.dp else 1.dp
        )
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            ProductCardHeader(
                title = product.title,
                subtitle = product.subtitle,
                categoryTag = product.categoryTag,
                imageRes = product.imageRes,
                isActive = isActiveProduct
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "1. Size & Quantity",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                product.sizeOptions.forEach { sizeOption ->
                    val isSizeSelected = isActiveProduct && selectedSizeId == sizeOption.id
                    OptionPriceRow(
                        label = sizeOption.label,
                        detail = "${sizeOption.specDetail} • From ${formatInr(sizeOption.frontOnlyPriceInr)}",
                        priceInr = sizeOption.priceFor(selectedSide),
                        selected = isSizeSelected,
                        onClick = { onSelectSize(sizeOption.id) },
                        modifier = Modifier.testTag("option_${sizeOption.id}")
                    )
                }

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant,
                    modifier = Modifier.padding(vertical = 2.dp)
                )

                Text(
                    text = "2. Printing Sides (${activeSizeOption.label})",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PrintSideOption.entries.forEach { side ->
                        val sideSelected = isActiveProduct && selectedSide == side
                        val sidePrice = activeSizeOption.priceFor(side)
                        Surface(
                            color = if (sideSelected) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(
                                width = if (sideSelected) 1.5.dp else 1.dp,
                                color = if (sideSelected) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.outlineVariant
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 54.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelectSide(side) }
                                .testTag("pamphlet_side_${side.name.lowercase()}")
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Text(
                                    text = side.label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (sideSelected) {
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )
                                Text(
                                    text = formatInr(sidePrice),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (sideSelected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductCardHeader(
    title: String,
    subtitle: String,
    categoryTag: String,
    imageRes: Int,
    isActive: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isActive) {
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.30f)
                } else {
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                }
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = imageRes),
            contentDescription = "$title print sample",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(width = 86.dp, height = 66.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outlineVariant,
                    shape = RoundedCornerShape(12.dp)
                )
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = if (isActive) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.secondaryContainer
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = categoryTag,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isActive) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        },
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                if (isActive) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "Selected product",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun OptionPriceRow(
    label: String,
    detail: String,
    priceInr: Int,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        },
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.outlineVariant
            }
        ),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (selected) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    }
                )
                Text(
                    text = detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Surface(
                color = if (selected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surface
                },
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = formatInr(priceInr),
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = if (selected) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun InstantBillBottomBar(
    selectedOrder: SelectedPrintOrder,
    onProceedToCheckout: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        shadowElevation = 10.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "INSTANT BILL • ${selectedOrder.productName.uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = selectedOrder.formattedPrice,
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = selectedOrder.configurationLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(bottom = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
                onClick = onProceedToCheckout,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .heightIn(min = 50.dp)
                    .testTag("proceed_to_checkout_button")
            ) {
                Text(
                    text = "Order Now",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Proceed to checkout",
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
