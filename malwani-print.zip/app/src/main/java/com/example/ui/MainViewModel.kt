package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AuthResult
import com.example.data.local.StoredSessionState
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.DesignAttachment
import com.example.data.model.DesignOption
import com.example.data.model.PaymentStatus
import com.example.data.model.PrintCatalog
import com.example.data.model.PrintProductId
import com.example.data.model.PrintSideOption
import com.example.data.model.SelectedPrintOrder
import com.example.data.model.UserProfile
import com.example.util.ExternalIntents
import kotlin.random.Random
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AuthMode {
    SIGN_IN,
    SIGN_UP
}

data class AuthUiState(
    val mode: AuthMode = AuthMode.SIGN_UP,
    val phoneInput: String = "",
    val pinInput: String = "",
    val otpInput: String = "",
    val generatedOtp: String? = null,
    val isOtpStepVisible: Boolean = false,
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null
)

data class CatalogSelectionState(
    val activeProductId: PrintProductId = PrintProductId.VISITING_CARD,
    val visitingCardOptionId: String = PrintCatalog.visitingCard.options.first().id,
    val pamphletSizeId: String = PrintCatalog.pamphlet.sizeOptions.first().id,
    val pamphletSide: PrintSideOption = PrintSideOption.FRONT_ONLY,
    val letterheadOptionId: String = PrintCatalog.letterhead.options.first().id,
    val envelopeOptionId: String = PrintCatalog.envelope.options.first().id
) {
    fun toSelectedOrder(): SelectedPrintOrder {
        return when (activeProductId) {
            PrintProductId.VISITING_CARD -> {
                val option = PrintCatalog.visitingCard.options
                    .firstOrNull { it.id == visitingCardOptionId }
                    ?: PrintCatalog.visitingCard.options.first()
                SelectedPrintOrder(
                    productId = PrintProductId.VISITING_CARD,
                    productName = PrintCatalog.visitingCard.title,
                    configurationLabel = option.label,
                    priceInr = option.priceInr
                )
            }
            PrintProductId.PAMPHLET -> {
                val sizeOption = PrintCatalog.pamphlet.sizeOptions
                    .firstOrNull { it.id == pamphletSizeId }
                    ?: PrintCatalog.pamphlet.sizeOptions.first()
                SelectedPrintOrder(
                    productId = PrintProductId.PAMPHLET,
                    productName = PrintCatalog.pamphlet.title,
                    configurationLabel = "${sizeOption.label} (${pamphletSide.label})",
                    priceInr = sizeOption.priceFor(pamphletSide)
                )
            }
            PrintProductId.LETTERHEAD -> {
                val option = PrintCatalog.letterhead.options
                    .firstOrNull { it.id == letterheadOptionId }
                    ?: PrintCatalog.letterhead.options.first()
                SelectedPrintOrder(
                    productId = PrintProductId.LETTERHEAD,
                    productName = PrintCatalog.letterhead.title,
                    configurationLabel = option.label,
                    priceInr = option.priceInr
                )
            }
            PrintProductId.ENVELOPE -> {
                val option = PrintCatalog.envelope.options
                    .firstOrNull { it.id == envelopeOptionId }
                    ?: PrintCatalog.envelope.options.first()
                SelectedPrintOrder(
                    productId = PrintProductId.ENVELOPE,
                    productName = PrintCatalog.envelope.title,
                    configurationLabel = option.label,
                    priceInr = option.priceInr
                )
            }
        }
    }
}

data class CheckoutUiState(
    val designOption: DesignOption = DesignOption.None,
    val paymentStatus: PaymentStatus = PaymentStatus.Idle,
    val lastOrderSummary: String? = null,
    val showDesignRequirementWarning: Boolean = false
)

data class MalwaniUiState(
    val session: StoredSessionState = StoredSessionState(),
    val auth: AuthUiState = AuthUiState(),
    val catalog: CatalogSelectionState = CatalogSelectionState(),
    val checkout: CheckoutUiState = CheckoutUiState()
) {
    val selectedOrder: SelectedPrintOrder
        get() = catalog.toSelectedOrder()
}

class MainViewModel(
    private val repository: UserPreferencesRepository
) : ViewModel() {

    private val authState = MutableStateFlow(AuthUiState())
    private val catalogState = MutableStateFlow(CatalogSelectionState())
    private val checkoutState = MutableStateFlow(CheckoutUiState())

    val uiState: StateFlow<MalwaniUiState> = combine(
        repository.sessionFlow,
        authState,
        catalogState,
        checkoutState
    ) { session, auth, catalog, checkout ->
        MalwaniUiState(
            session = session,
            auth = auth,
            catalog = catalog,
            checkout = checkout
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = MalwaniUiState()
    )

    fun setAuthMode(mode: AuthMode) {
        authState.update {
            it.copy(
                mode = mode,
                otpInput = "",
                generatedOtp = null,
                isOtpStepVisible = false,
                errorMessage = null
            )
        }
    }

    fun onPhoneInputChanged(input: String) {
        val cleaned = input.filter { it.isDigit() }.take(10)
        authState.update {
            it.copy(
                phoneInput = cleaned,
                isOtpStepVisible = false,
                generatedOtp = null,
                otpInput = "",
                errorMessage = null
            )
        }
    }

    fun onPinInputChanged(input: String) {
        val cleaned = input.filter { it.isDigit() }.take(4)
        authState.update { it.copy(pinInput = cleaned, errorMessage = null) }
    }

    fun onOtpInputChanged(input: String) {
        val cleaned = input.filter { it.isDigit() }.take(4)
        authState.update { it.copy(otpInput = cleaned, errorMessage = null) }
    }

    fun requestOtpOrSubmitAuth() {
        val current = authState.value
        val phone = UserPreferencesRepository.normalizePhone(current.phoneInput)
        if (!UserPreferencesRepository.isValidIndianMobile(phone)) {
            authState.update {
                it.copy(errorMessage = "Enter a valid 10-digit Indian mobile number starting with 6-9.")
            }
            return
        }
        if (current.pinInput.length != 4) {
            authState.update {
                it.copy(errorMessage = "Please enter a 4-digit security PIN.")
            }
            return
        }

        viewModelScope.launch {
            if (current.mode == AuthMode.SIGN_UP && !current.isOtpStepVisible) {
                if (repository.hasRegisteredAccount(phone)) {
                    authState.update {
                        it.copy(
                            mode = AuthMode.SIGN_IN,
                            errorMessage = "Number +91 $phone is already registered. Enter your PIN to sign in."
                        )
                    }
                    return@launch
                }
                val code = Random.nextInt(1000, 9999).toString()
                authState.update {
                    it.copy(
                        generatedOtp = code,
                        isOtpStepVisible = true,
                        otpInput = "",
                        errorMessage = null
                    )
                }
                return@launch
            }

            if (current.mode == AuthMode.SIGN_UP && current.isOtpStepVisible) {
                if (current.otpInput != current.generatedOtp) {
                    authState.update {
                        it.copy(errorMessage = "Verification code does not match. Check the 4-digit code shown above.")
                    }
                    return@launch
                }
            }

            authState.update { it.copy(isSubmitting = true, errorMessage = null) }
            val result = when (current.mode) {
                AuthMode.SIGN_UP -> repository.signUpWithPhoneAndPin(phone, current.pinInput)
                AuthMode.SIGN_IN -> repository.signInWithPhoneAndPin(phone, current.pinInput)
            }
            when (result) {
                is AuthResult.Success -> {
                    authState.value = AuthUiState()
                }
                is AuthResult.Error -> {
                    authState.update {
                        it.copy(isSubmitting = false, errorMessage = result.message)
                    }
                }
            }
        }
    }

    fun saveUserProfile(
        name: String,
        contactNumber: String,
        deliveryAddress: String,
        onSaved: () -> Unit
    ) {
        viewModelScope.launch {
            repository.saveProfile(name, contactNumber, deliveryAddress)
            onSaved()
        }
    }

    fun signOut() {
        viewModelScope.launch {
            repository.signOut()
            checkoutState.value = CheckoutUiState()
            authState.value = AuthUiState(mode = AuthMode.SIGN_IN)
        }
    }

    fun selectVisitingCard(optionId: String) {
        catalogState.update {
            it.copy(
                activeProductId = PrintProductId.VISITING_CARD,
                visitingCardOptionId = optionId
            )
        }
        resetCheckoutProgressIfOrderChanged()
    }

    fun selectPamphletSize(sizeId: String) {
        catalogState.update {
            it.copy(
                activeProductId = PrintProductId.PAMPHLET,
                pamphletSizeId = sizeId
            )
        }
        resetCheckoutProgressIfOrderChanged()
    }

    fun selectPamphletSide(side: PrintSideOption) {
        catalogState.update {
            it.copy(
                activeProductId = PrintProductId.PAMPHLET,
                pamphletSide = side
            )
        }
        resetCheckoutProgressIfOrderChanged()
    }

    fun selectLetterhead(optionId: String) {
        catalogState.update {
            it.copy(
                activeProductId = PrintProductId.LETTERHEAD,
                letterheadOptionId = optionId
            )
        }
        resetCheckoutProgressIfOrderChanged()
    }

    fun selectEnvelope(optionId: String) {
        catalogState.update {
            it.copy(
                activeProductId = PrintProductId.ENVELOPE,
                envelopeOptionId = optionId
            )
        }
        resetCheckoutProgressIfOrderChanged()
    }

    fun activateProduct(productId: PrintProductId) {
        catalogState.update { it.copy(activeProductId = productId) }
        resetCheckoutProgressIfOrderChanged()
    }

    private fun resetCheckoutProgressIfOrderChanged() {
        checkoutState.update {
            if (it.paymentStatus is PaymentStatus.Confirmed) {
                CheckoutUiState()
            } else {
                it.copy(
                    paymentStatus = PaymentStatus.Idle,
                    showDesignRequirementWarning = false
                )
            }
        }
    }

    fun onDesignUploaded(attachment: DesignAttachment) {
        checkoutState.update {
            it.copy(
                designOption = DesignOption.UploadedFile(attachment),
                showDesignRequirementWarning = false
            )
        }
    }

    fun onMakeNewDesignSelected() {
        checkoutState.update {
            it.copy(
                designOption = DesignOption.MakeNewDesignRequested,
                showDesignRequirementWarning = false
            )
        }
    }

    fun clearDesignAttachment() {
        checkoutState.update {
            it.copy(designOption = DesignOption.None)
        }
    }

    fun warnDesignRequired() {
        checkoutState.update {
            it.copy(showDesignRequirementWarning = true)
        }
    }

    fun markUpiInitiated() {
        checkoutState.update {
            if (it.paymentStatus is PaymentStatus.Confirmed) it
            else it.copy(paymentStatus = PaymentStatus.AwaitingExternalConfirmation)
        }
    }

    fun confirmUpiPayment(referenceId: String, profile: UserProfile): String {
        val cleanRef = referenceId.trim().ifBlank {
            "UPI-${System.currentTimeMillis().toString().takeLast(6)}"
        }
        val order = catalogState.value.toSelectedOrder()
        val summary = ExternalIntents.buildOrderSummaryMessage(profile, order)
        checkoutState.update {
            it.copy(
                paymentStatus = PaymentStatus.Confirmed(cleanRef),
                lastOrderSummary = summary
            )
        }
        return summary
    }

    fun resetOrderForNewPurchase() {
        checkoutState.value = CheckoutUiState()
    }

    class Factory(
        private val repository: UserPreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(repository) as T
        }
    }
}
